import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../services/haptic_service.dart';
import '../../services/sound_service.dart';
import '../../services/user_activity_service.dart';

import 'dart:async';
import '../../providers/switch_provider.dart';
import '../../providers/switch_schedule_provider.dart';
import '../../providers/animation_provider.dart';
import '../../providers/live_info_provider.dart';

import '../../widgets/robo/robo_assistant.dart';
import '../../widgets/robo/robo_assistant.dart' as robo;
import '../../widgets/live_info/time_date_widget.dart';
import '../../widgets/live_info/status_card.dart';
import '../../widgets/live_info/connection_status_pill.dart';
import '../../widgets/switch_grid/switch_grid.dart';
import '../../widgets/voice/voice_assistant_overlay.dart';
import '../../widgets/common/frosted_glass.dart';
import '../../widgets/common/pixel_led_border.dart';
import '../../widgets/common/switch_tab_background.dart';
import '../../widgets/navigation/animated_nav_icon.dart';
import '../../widgets/common/premium_app_bar.dart';
import '../../core/constants/app_constants.dart';
import '../../core/ui/responsive_layout.dart';
import '../../core/ui/global_layout_engine.dart';
import '../../providers/google_home_provider.dart';
import '../../services/google_assistant_service.dart';

import '../settings/settings_screen.dart';
import 'security_view.dart';
import '../../widgets/scheduler/scheduler_settings_popup.dart';
import '../../widgets/help/help_bot_overlay.dart';

final helpBotVisibleProvider = StateProvider<bool>((ref) => false);

class MainScreen extends ConsumerStatefulWidget {
  const MainScreen({super.key});

  @override
  ConsumerState<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends ConsumerState<MainScreen>
    with WidgetsBindingObserver {
  int _currentPage = 0;

  Timer? _schedulerTimer;
  final Map<String, DateTime> _lastFiredSchedules = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    ref.read(userActivityServiceProvider);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      robo.triggerRoboReaction(ref, robo.RoboReaction.wakeUp);
      Future.delayed(const Duration(milliseconds: 500), () {
        ref.read(soundServiceProvider).playStartup();
      });
    });

    _schedulerTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      _checkSchedules();
    });
  }

  void _checkSchedules() {
    final now = DateTime.now();
    final schedules = ref.read(switchScheduleProvider);
    final switchService = ref.read(firebaseSwitchServiceProvider);

    for (final schedule in schedules) {
      if (!schedule.isEnabled) continue;

      if (schedule.hour == now.hour && schedule.minute == now.minute) {
        if (schedule.days.isNotEmpty && !schedule.days.contains(now.weekday)) {
          continue;
        }

        final lastFired = _lastFiredSchedules[schedule.id];
        if (lastFired != null &&
            lastFired.year == now.year &&
            lastFired.month == now.month &&
            lastFired.day == now.day &&
            lastFired.hour == now.hour &&
            lastFired.minute == now.minute) {
          continue;
        }

        final commandValue = schedule.targetState ? 1 : 0;
        switchService.sendCommand(
          schedule.relayId,
          commandValue,
          triggeredBy: 'scheduler',
        );

        _lastFiredSchedules[schedule.id] = now;
      }
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _schedulerTimer?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {}
  }

  void _onPageChanged(int index) {
    setState(() {
      _currentPage = index;
    });
  }

  void _onBottomNavTapped(int index) {
    if (_currentPage == index) return;

    HapticService.selection();
    final soundService = ref.read(soundServiceProvider);
    Future.microtask(() => soundService.playTabSwitch());

    robo.triggerRoboReaction(ref, robo.RoboReaction.blink);

    setState(() => _currentPage = index);

    // Replaced PageView mechanics with instantaneous non-blocking state rebuilds
    // Transitions are now strictly handled by opacity fades via the IndexedStack hooks.
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBody: false, // Fix overlap with bottom nav
      bottomNavigationBar: _buildBottomNav(theme),
      body: Stack(
        children: [
          const Positioned.fill(child: ColoredBox(color: Colors.black)),
          Positioned.fill(
            top: 85.h + Responsive.paddingTop,
            child: AnimatedOpacity(
              opacity: _currentPage == 1 ? 1.0 : 0.0,
              duration: const Duration(milliseconds: 400),
              curve: Curves.easeOut,
              child: const RepaintBoundary(
                child: SwitchTabBackground(child: SizedBox.expand()),
              ),
            ),
          ),
          SafeArea(
            bottom: false,
            child: IndexedStack(
              index: _currentPage,
              children: [
                _buildFadeTab(0, const DashboardView()),
                _buildFadeTab(1, const ControlView()),
                _buildFadeTab(2, const SecurityView()),
                _buildFadeTab(3, const SettingsScreen()),
              ],
            ),
          ),
          if (ref.watch(helpBotVisibleProvider))
            HelpBotOverlay(
              onComplete: () =>
                  ref.read(helpBotVisibleProvider.notifier).state = false,
            ),
        ],
      ),
    );
  }

  Widget _buildFadeTab(int index, Widget child) {
    return AnimatedOpacity(
      opacity: _currentPage == index ? 1.0 : 0.0,
      duration: const Duration(milliseconds: 350),
      curve: Curves.easeOutCubic,
      child: IgnorePointer(
        ignoring: _currentPage != index,
        child: child,
      ),
    );
  }

  Widget _buildBottomNav(ThemeData theme) {
    final themeColors = [
      theme.colorScheme.primary,
      theme.colorScheme.secondary,
      theme.colorScheme.tertiary,
      theme.colorScheme.primary,
    ];

    return PixelLedBorder(
      borderRadius: 24.r,
      strokeWidth: 0.5, // Subtle neon — emphasis moved to top
      colors: themeColors,
      duration: const Duration(seconds: 4),
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF0A0A0A).withOpacity(0.85),
          borderRadius: BorderRadius.vertical(top: Radius.circular(24.r)),
          boxShadow: const [],
        ),
        child: SafeArea(
          top: false,
          child: Container(
            height: 65.h,
            child: BottomNavigationBar(
              currentIndex: _currentPage,
              onTap: _onBottomNavTapped,
              backgroundColor: Colors.transparent,
              selectedItemColor: theme.colorScheme.primary,
              unselectedItemColor: Colors.white.withOpacity(0.3),
              showSelectedLabels: true,
              showUnselectedLabels: false,
              selectedLabelStyle: GoogleFonts.outfit(
                fontSize: 10.sp,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.2.w,
              ),
              elevation: 0,
              type: BottomNavigationBarType.fixed,
              items: [
                _buildNavItem(Icons.dashboard_rounded, 'CORE', 0),
                _buildNavItem(Icons.grid_view_rounded, 'GRID', 1),
                _buildNavItem(Icons.security_rounded, 'SECURITY', 2),
                _buildNavItem(Icons.settings_suggest_rounded, 'SETUP', 3),
              ],
            ),
          ),
        ),
      ),
    );
  }

  BottomNavigationBarItem _buildNavItem(
    IconData icon,
    String label,
    int index,
  ) {
    return BottomNavigationBarItem(
      icon: AnimatedNavIcon(icon: icon, isSelected: false, label: label),
      activeIcon: AnimatedNavIcon(icon: icon, isSelected: true, label: label),
      label: label,
    );
  }
}

class DashboardView extends ConsumerWidget {
  const DashboardView({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final liveInfo = ref.watch(liveInfoProvider);
    final systemState = liveInfo.acVoltage >= 100
        ? "GRID SYNC ACTIVE\nNebula Protection Enabled"
        : "GRID OFFLINE\nMonitoring Power State";

    final layout = GlobalLayoutEngine.solve(
      screenHeight: MediaQuery.of(context).size.height,
      screenWidth: MediaQuery.of(context).size.width,
      topPadding: MediaQuery.of(context).padding.top,
      bottomPadding: MediaQuery.of(context).padding.bottom,
      bottomNavHeight: 65.h, // Explicitly pass for quantum precision
    );

    return Stack(
      children: [
        // ULTRA-PREMIUM FLOATING AURA: Subtle, deep background movement
        const Positioned.fill(child: SizedBox.shrink()),
        SafeArea(
          child: Padding(
            padding: EdgeInsets.symmetric(
              horizontal: Responsive.horizontalPadding,
            ),
            child: Column(
              children: [
                SizedBox(height: layout.verticalOffset),
                SizedBox(height: 65.h), // Base spacing for AppBar area
                Transform.scale(
                  scale: layout.pillScale,
                  child: const ConnectionStatusPill(),
                ),
                SizedBox(height: layout.pillScale == 1.0 ? 0 : layout.gaps[0]),
                RepaintBoundary(
                      child: Transform.scale(
                        scale: layout.roboScale,
                        child: const RoboAssistant(
                          eyesOnly: true,
                          autoTuneEnabled: false,
                        ),
                      ),
                    )
                    .animate()
                    .fadeIn(duration: 80.ms)
                    .slideY(
                      begin: 0.1,
                      end: 0,
                      duration: 80.ms,
                      curve: Curves.easeOutCubic,
                    ),
                SizedBox(height: layout.gaps[1]),
                RepaintBoundary(
                      child: Transform.scale(
                        scale: layout.timeScale,
                        child: const TimeDateWidget(),
                      ),
                    )
                    .animate()
                    .fadeIn(delay: 100.ms, duration: 80.ms)
                    .slideY(
                      begin: 0.1,
                      end: 0,
                      duration: 80.ms,
                      curve: Curves.easeOutCubic,
                    ),
                SizedBox(height: layout.gaps[2]),
                RepaintBoundary(
                      child: Transform.scale(
                        scale: layout.statusScale,
                        child: StatusCard(
                          voltage: liveInfo.acVoltage,
                          systemState: systemState,
                        ),
                      ),
                    )
                    .animate(onPlay: (c) => c.repeat(reverse: true))
                    .moveY(
                      begin: 0,
                      end: -4,
                      duration: 3.seconds,
                      curve: Curves.easeInOut,
                    ),
                SizedBox(height: layout.gaps[3]),
                RepaintBoundary(
                      child: Transform.scale(
                        scale: layout.actionScale,
                        child: const _ActionButtons(),
                      ),
                    )
                    .animate()
                    .fadeIn(delay: 200.ms, duration: 80.ms)
                    .slideY(
                      begin: 0.1,
                      end: 0,
                      duration: 80.ms,
                      curve: Curves.easeOutCubic,
                    ),
                SizedBox(height: layout.gaps[4]),
              ],
            ),
          ),
        ),
        Positioned(
          top: 0,
          left: 0,
          right: 0,
          child: PremiumAppBar(
            glowIntensity: liveInfo.acVoltage >= 180 ? 0.7 : 0.3,
            title: Row(
              children: [
                ShaderMask(
                  shaderCallback: (Rect bounds) {
                    return LinearGradient(
                      colors: [
                        Colors.white,
                        theme.colorScheme.primary.withOpacity(0.8),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      stops: const [0.3, 1.0],
                    ).createShader(bounds);
                  },
                  blendMode: BlendMode.srcIn,
                  child: Transform.scale(
                    scale: layout.headerScale,
                    child: Text(
                      'NEBULA CORE',
                      style: GoogleFonts.outfit(
                        fontSize: 22.sp,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 4.w,
                        shadows: [
                          Shadow(
                            color: theme.colorScheme.primary.withOpacity(0.5),
                            blurRadius: 20,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
            trailing: _EnvironmentInfo(
              theme: theme,
              temp: liveInfo.temperature,
              iconName: liveInfo.weatherIcon,
            ),
          ),
        ),
      ],
    );
  }
}

class _EnvironmentInfo extends StatelessWidget {
  final ThemeData theme;
  final double temp;
  final String iconName;

  const _EnvironmentInfo({
    required this.theme,
    required this.temp,
    required this.iconName,
  });

  @override
  Widget build(BuildContext context) {
    IconData icon = iconName.contains('Sun')
        ? Icons.wb_sunny_rounded
        : iconName.contains('Cloud')
        ? Icons.cloud
        : iconName.contains('Moon')
        ? Icons.nights_stay_rounded
        : Icons.wb_sunny_rounded;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: theme.colorScheme.secondary, size: 16),
          const SizedBox(width: 8),
          Text(
            '${temp.toStringAsFixed(1)}°C',
            style: GoogleFonts.roboto(
              fontSize: 14.sp,
              fontWeight: FontWeight.w600,
              color: theme.colorScheme.onSurface.withOpacity(0.9),
            ),
          ),
        ],
      ),
    );
  }
}

class _ActionButtons extends ConsumerWidget {
  const _ActionButtons();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final googleHomeLinked = ref.watch(googleHomeLinkedProvider);
    final assistantService = ref.watch(googleAssistantServiceProvider);

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: Responsive.horizontalPadding),
      child: Row(
        children: [
          Expanded(
            child: _GlassButton(
              label: "Google Home",
              icon: Icons.home_rounded,
              isActive: googleHomeLinked.valueOrNull == true,
              theme: theme,
              onTap: () => _showGoogleHomeDialog(context, ref),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: _GlassButton(
              label: "Assistant",
              icon: assistantService.isListening
                  ? Icons.mic
                  : Icons.mic_none_rounded,
              isActive: assistantService.isListening,
              theme: theme,
              activeColor: Colors.orangeAccent,
              onTap: () async {
                await showModalBottomSheet(
                  context: context,
                  backgroundColor: Colors.transparent,
                  barrierColor: Colors.transparent,
                  isScrollControlled: true,
                  builder: (context) => const VoiceAssistantOverlay(),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _showGoogleHomeDialog(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder: (context) => Consumer(
        builder: (context, ref, _) {
          final googleHomeLinked =
              ref.watch(googleHomeLinkedProvider).valueOrNull ?? false;
          final service = ref.read(googleHomeServiceProvider);
          final theme = Theme.of(context);

          return Dialog(
            backgroundColor: Colors.transparent,
            child: FrostedGlass(
              padding: const EdgeInsets.all(24),
              radius: BorderRadius.circular(28),
              border: Border.all(
                color: theme.colorScheme.primary.withOpacity(0.3),
                width: 1.2,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Google Home',
                    style: theme.textTheme.headlineMedium?.copyWith(
                      fontSize: 24.sp,
                    ),
                  ),
                  SizedBox(height: 16.h),
                  Text(
                    googleHomeLinked
                        ? 'Google Home is linked. Your devices are synced to the cloud.'
                        : 'Google Home is not linked. Link it to sync devices across platforms.',
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      if (googleHomeLinked)
                        TextButton(
                          onPressed: () async {
                            await service.unlinkGoogleHome();
                            Navigator.of(context).pop();
                          },
                          child: const Text('Unlink'),
                        ),
                      if (!googleHomeLinked)
                        ElevatedButton(
                          onPressed: () async {
                            await service.linkGoogleHome();
                            Navigator.of(context).pop();
                          },
                          child: const Text('Link'),
                        ),
                      const SizedBox(width: 8),
                      TextButton(
                        onPressed: () => Navigator.of(context).pop(),
                        child: const Text('Close'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _GlassButton extends StatefulWidget {
  final String label;
  final IconData icon;
  final bool isActive;
  final ThemeData theme;
  final VoidCallback onTap;
  final Color? activeColor;

  const _GlassButton({
    required this.label,
    required this.icon,
    required this.isActive,
    required this.theme,
    required this.onTap,
    this.activeColor,
  });

  @override
  State<_GlassButton> createState() => _GlassButtonState();
}

class _GlassButtonState extends State<_GlassButton> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    final isNeon = widget.isActive;
    final themeColors = [
      widget.theme.colorScheme.primary,
      widget.theme.colorScheme.secondary,
      widget.theme.colorScheme.tertiary,
      widget.theme.colorScheme.primary,
    ];

    return GestureDetector(
      onTapDown: (_) => setState(() => _isPressed = true),
      onTapUp: (_) => setState(() => _isPressed = false),
      onTapCancel: () => setState(() => _isPressed = false),
      onTap: () {
        HapticService.selection();
        widget.onTap();
      },
      child: AnimatedScale(
        scale: _isPressed ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 80),
        child: Container(
          height: 80,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            boxShadow: const [],
          ),
          child: PixelLedBorder(
            colors: themeColors,
            borderRadius: 28,
            strokeWidth: 1.5,
            duration: const Duration(milliseconds: 2500),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xFF0A0A0A),
                borderRadius: BorderRadius.circular(28),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ShaderMask(
                    shaderCallback: (Rect bounds) {
                      return LinearGradient(
                        colors: [
                          widget.theme.colorScheme.primary,
                          widget.theme.colorScheme.secondary,
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ).createShader(bounds);
                    },
                    blendMode: BlendMode.srcIn,
                    child: Icon(widget.icon, color: Colors.white, size: 30)
                        .animate(onPlay: (c) => c.repeat(reverse: true))
                        .scale(
                          begin: const Offset(1, 1),
                          end: const Offset(1.1, 1.1),
                          duration: 2.seconds,
                          curve: Curves.easeInOut,
                        )
                        .shimmer(duration: 3.seconds, color: Colors.white24),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    widget.label,
                    style: GoogleFonts.outfit(
                      fontSize: 14,
                      fontWeight: isNeon ? FontWeight.bold : FontWeight.w500,
                      color: Colors.white.withOpacity(isNeon ? 0.9 : 0.6),
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class ControlView extends ConsumerStatefulWidget {
  const ControlView({super.key});

  @override
  ConsumerState<ControlView> createState() => _ControlViewState();
}

class _ControlViewState extends ConsumerState<ControlView> {
  bool _isInitComplete = false;

  @override
  void initState() {
    super.initState();
    _isInitComplete = true;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final topPadding = MediaQuery.of(context).padding.top;
    final contentTopPadding = topPadding + 65.h + 20.h;

    return Stack(
      children: [
        if (!_isInitComplete)
          Center(
            child: Container(
              width: double.infinity,
              height: 300,
              margin: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.05),
                borderRadius: BorderRadius.circular(24),
              ),
            ),
          )
        else
          Padding(
            padding: EdgeInsets.only(top: contentTopPadding),
            child: const ClipRect(child: SwitchGrid()),
          ),
        Positioned(
          top: 0,
          left: 0,
          right: 0,
          child: PremiumAppBar(
            glowIntensity: 0.5,
            title: ShaderMask(
              shaderCallback: (Rect bounds) {
                return LinearGradient(
                  colors: [
                    theme.colorScheme.primary,
                    theme.colorScheme.secondary,
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ).createShader(bounds);
              },
              blendMode: BlendMode.srcIn,
              child: Text(
                'SMART SWITCHES',
                style: GoogleFonts.outfit(
                  fontSize: 18.sp,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5.w,
                  shadows: [
                    Shadow(
                      color: theme.colorScheme.primary.withOpacity(0.3),
                      blurRadius: 10,
                    ),
                  ],
                ),
              ),
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                      icon: Icon(
                        Icons.alarm_add_rounded,
                        color: theme.colorScheme.primary,
                      ),
                      onPressed: () {
                        HapticService.selection();
                        showModalBottomSheet(
                          context: context,
                          isScrollControlled: true,
                          backgroundColor: Colors.transparent,
                          builder: (context) => const SchedulerSettingsPopup(
                            initialDeviceId: AppConstants.defaultDeviceId,
                          ),
                        );
                      },
                    )
                    .animate(onPlay: (c) => c.repeat(reverse: true))
                    .scale(
                      begin: const Offset(1, 1),
                      end: const Offset(1.1, 1.1),
                      duration: 2.seconds,
                      curve: Curves.easeInOut,
                    )
                    .shimmer(duration: 3.seconds, color: Colors.white24),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
