import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../services/haptic_service.dart';
import 'package:flutter_animate/flutter_animate.dart';

import 'package:google_fonts/google_fonts.dart';
import '../../providers/switch_provider.dart';
import '../../services/voice_service.dart';
import '../../services/sound_service.dart';
import '../../widgets/robo/robo_assistant.dart' as robo;
// Removed unused import
import '../../core/constants/app_constants.dart';
import '../../core/ui/responsive_layout.dart';
import 'switch_tile.dart';
import '../scheduler/scheduler_settings_popup.dart';

class SwitchGrid extends ConsumerWidget {
  const SwitchGrid({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final devices = ref.watch(switchDevicesProvider);

    if (devices.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircularProgressIndicator(color: Colors.cyanAccent),
            const SizedBox(height: 24),
            Text(
              'Waiting for device to come online...',
              style: GoogleFonts.outfit(
                color: Colors.grey,
                fontSize: 14.sp,
                letterSpacing: 1.1.w,
              ),
            ),
          ],
        ),
      );
    }

    Widget grid = RepaintBoundary(
      child: GridView.builder(
        padding: EdgeInsets.fromLTRB(
          Responsive.horizontalPadding,
          0,
          Responsive.horizontalPadding,
          100.h,
        ),
        physics: const BouncingScrollPhysics(),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: Responsive.gridColumns,
          crossAxisSpacing: AppConstants.gridSpacing.w,
          mainAxisSpacing: AppConstants.gridSpacing.h,
          childAspectRatio: 1.0,
        ),
        itemCount: devices.length,
        itemBuilder: (context, index) {
          final device = devices[index];
          return RepaintBoundary(
            child:
                SwitchTile(
                      device: device,
                      onTap: () {
                        HapticService.selection();
                        ref
                            .read(switchDevicesProvider.notifier)
                            .toggleSwitch(device.id);

                        // 1. INSTANT: Fire Sound Effect on microtask to guarantee 0ms UI lock
                        final soundService = ref.read(soundServiceProvider);
                        Future.microtask(() {
                          if (!device.isActive) {
                            soundService.playSwitchOn();
                          } else {
                            soundService.playSwitchOff();
                          }
                        });

                        // 2. INSTANT: Visual Reaction
                        robo.triggerRoboReaction(ref, robo.RoboReaction.nod);

                        // 3. DEFERRED: Voice Synthesis (MethodChannels can block the thread, causing huge latency jank)
                        final voiceService = ref.read(voiceServiceProvider);
                        final status = !device.isActive ? 'on' : 'off';
                        Future.delayed(const Duration(milliseconds: 150), () {
                          voiceService.speak('${device.name} is $status.');
                        });
                      },
                      onLongPress: () {
                        HapticService.medium();
                        showModalBottomSheet(
                          context: context,
                          isScrollControlled: true,
                          backgroundColor: Colors.transparent,
                          builder: (context) => SchedulerSettingsPopup(
                            initialDeviceId: device.id,
                          ),
                        );
                      },
                    )
                    .animate()
                    .fadeIn(delay: (index * 50).ms, duration: 80.ms)
                    .scale(
                      begin: const Offset(0.9, 0.9),
                      end: const Offset(1, 1),
                      delay: (index * 50).ms,
                      duration: 80.ms,
                      curve: Curves.easeOutCubic,
                    ),
          );
        },
      ),
    );

    return grid;
  }
}
